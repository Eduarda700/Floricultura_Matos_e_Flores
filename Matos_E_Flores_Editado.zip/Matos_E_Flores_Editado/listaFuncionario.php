<?php
include_once './conexao.php';
include_once './usuarioProprietaria.php';
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!!";
    header("Location: index.php");
    exit;
}

if (isset($_GET['excluir'])) {
    $idExcluir = intval($_GET['excluir']);
    $stmt = $conn->prepare("DELETE FROM usuario_funcionario WHERE idusuario_funcionario = ?");
    $stmt->bind_param("i", $idExcluir);
    $stmt->execute();
    $stmt->close();

    header("Location: listaFuncionario.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lista de Funcionários</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>

        .page-title-box {
            font-family: Baskerville Old Face;
            background-color: #d3bdf0;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .page-title-box h2 { color: #3c1361; margin: 0; }
        .table-bordered > thead > tr { background-color: #d3bdf0; color: #3c1361; }
        .btn-danger { background-color: #9c27b0; border-color: #8e24aa; }
        .btn-danger:hover { background-color: #7b1fa2; border-color: #6a1b9a; }
    </style>
</head>
<body>
<header>
        <div class="header-container">
            <div class="logo">
            <a href="homeFuncionario.php"><img src="logo_header.png" alt="Logo da floricultura" class="logo-img"></a>
        <div class="logo-texto">
    <h1>Matos e Flores</h1>
    <span>Loja de Plantas Ornamentais</span>
  </div>
</div>
            <nav>
                <ul>
                     <li><a href="homeProprietaria.php">Início</a></li>
                     <li><a href="cadastroFuncionario.php">Cadastro Funcionário</a></li>
                     <li><a href="listaFuncionario.php">Lista Funcionários</a></li>
                     <li><a href="listaFornecedores.php">Lista Fornecedores</a></li>

                </ul>
            </nav>
            <div class="user-actions">
               <div class="user-actions">
                <div class="user-greeting">
                    Olá, <?php echo $_SESSION['user']->nome_proprietaria; ?>!
                </div>
                <a href="logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>
<div class="container">
    <div class="page-title-box">
        <h2>Funcionários Cadastrados</h2>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Código</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Senha</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $consulta = mysqli_query($conn, "SELECT idusuario_funcionario, nome_funcionario, email_funcionario, senha_funcionario FROM usuario_funcionario");
            while ($dados = mysqli_fetch_array($consulta, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($dados['idusuario_funcionario']); ?></td>
                    <td><?php echo htmlspecialchars($dados['nome_funcionario']); ?></td>
                    <td><?php echo htmlspecialchars($dados['email_funcionario']); ?></td>
                    <td><?php echo htmlspecialchars($dados['senha_funcionario']); ?></td>
                    <td>
                        <a href="listaFuncionario.php?excluir=<?php echo $dados['idusuario_funcionario']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Tem certeza que deseja excluir este funcionário?');">
                            Deletar
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>