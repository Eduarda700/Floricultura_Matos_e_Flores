<?php
include_once './conexao.php';
include_once './usuarioFuncionario.php';
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!!";
    header("Location: index.php");
    exit;
}
// Consulta para listar produtos
$sql = "SELECT * FROM produto";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
     <style>
        .btn-novo {
            background-color: #3c1361;
            color: white;
            border: none;
            border-radius: 6px;
        }

        .btn-novo:hover {
            background-color:rgb(37, 6, 63);
            color:white;
        }

        .btn-editar {
            background-color: #d3bdf0;
            color: #3c1361;
            border: none;
            border-radius: 4px;
        }

        .btn-editar:hover {
            background-color: #c0aee0;
        }

        .btn-excluir {
            background-color: #3c1361;
            color: white;
            border: none;
            border-radius: 4px;
        }

        .btn-excluir:hover {
            background-color:rgb(37, 6, 63);
            color: #d3bdf0;
        }

        .table {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
        }

        .table th {
            background-color: #d3bdf0;
            color: #3c1361;
            font-weight: bold;
        }

        .table td, .table th {
            vertical-align: middle;
        }
    </style>
</head>
<body>
<header>
        <div class="header-container">
            <div class="logo">
            <a href="homeFuncionario.php"><img src="logo_header.png" alt="Logo da floricultura" class="logo-img"></a>
        <div class="logo-texto">
    <h1>Matos e Flores</h1>
    <span>Loja de Plantas Ornamentais</span>
  </div>
</div>
            <nav>
                <ul>
                    <li><a href="homeFuncionario.php">Início</a></li>
                    <li><a href="cadastraProdutos.php">Lista Produtos</a></li>
                    <li><a href="lista_dica.php">Lista Dicas de Plantio</a></li>
                   <li><a href="pedidos_andamento.php">Lista de Pedidos </a></li>
                </ul>
            </nav>
            <div class="user-actions">
               <div class="user-actions">
                <div class="user-greeting">
                    Olá, <?php echo $_SESSION['user']->nome_funcionario; ?>!
                </div>
                <a href="logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Lista de Produtos</h2>
        <button class="btn btn-novo" data-bs-toggle="modal" data-bs-target="#modalCadastroProduto">Novo Produto</button>
    </div>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Código</th>
                <th>Quantidade</th>
                <th>Valor</th>
                <th>ID Fornecedor</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['nome_produto']) ?></td>
                <td><?= htmlspecialchars($row['cod_produto']) ?></td>
                <td><?= $row['quantidade_produto'] ?></td>
                <td>R$ <?= $row['valor_produto'] ?></td>
                <td><?= $row['idfornecedor'] ?></td>
                <td>
                    <a href="editarProduto.php?id=<?= $row['idproduto'] ?>" class="btn btn-editar btn-sm">Editar</a>
                    <a href="excluirProduto.php?id=<?= $row['idproduto'] ?>" class="btn btn-excluir btn-sm">Excluir</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<?php include 'modalProduto.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>