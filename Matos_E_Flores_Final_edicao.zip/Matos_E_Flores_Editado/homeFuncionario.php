<?php
include_once './conexao.php';
include_once './usuarioFuncionario.php';
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!!";
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home Funcionário - Sistema Floricultura</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<header>
        <div class="header-container">
            <div class="logo">
            <a href="homeFuncionario.php"><img src="logo_header.png" alt="Logo da floricultura" class="logo-img"></a>
        <div class="logo-texto">
    <h1>Matos e Flores</h1>
    <span>Loja de Plantas Ornamentais</span>
  </div>
</div>
            <nav>
                <ul>
                    <li><a href="homeFuncionario.php">Início</a></li>
                    <li><a href="cadastraProdutos.php">Lista Produtos</a></li>
                    <li><a href="lista_dica.php">Lista Dicas de Plantio</a></li>
                   <li><a href="pedidos_andamento.php">Lista de Pedidos </a></li>
                </ul>
            </nav>
            <div class="user-actions">
               <div class="user-actions">
                <div class="user-greeting">
                    Olá, <?php echo $_SESSION['user']->nome_funcionario; ?>!
                </div>
                <a href="logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>

<div class="boas-vindas">
    <div class="titulo-bem-vindo">
        <h2>Bem-vindo(a), <?php echo $_SESSION['user']->nome_funcionario; ?>!</h2> 
    </div>
    <img src="funcionario.png" align-itens="center">
</div>

</body>
</html>