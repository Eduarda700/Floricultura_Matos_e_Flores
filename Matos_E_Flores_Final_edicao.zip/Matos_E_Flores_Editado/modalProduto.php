<!-- Modal Cadastro de Produto (Bootstrap 3) -->
<div class="modal fade" id="modalCadastroProduto" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
  <div class="modal-dialog modal-lg-custom" style="max-width: 1500px; width: 100%;" role="document"> <!-- Aumenta a largura -->
    <div class="modal-content">

      <!-- Cabeçalho -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="modalLabel">Cadastro de Produtos</h4>
      </div>

      <!-- Corpo -->
      <div class="modal-body">
        <form action="salvarProduto.php" method="POST" enctype="multipart/form-data">

          <div class="form-group row">
            <div class="col-md-6">
              <label for="nome_produto">Nome do Produto</label>
              <input type="text" name="nome_produto" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label for="cod_produto">Código</label>
              <input type="text" name="cod_produto" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label for="descricao_produto">Descrição do produto</label>
            <textarea name="descricao_produto" class="form-control" rows="3" required></textarea>
          </div>

          <div class="form-group row">
            <div class="col-md-4">
              <label for="quantidade_produto">Quantidade em Estoque</label>
              <input type="number" name="quantidade_produto" class="form-control" required>
            </div>
            <div class="col-md-4">
              <label for="valor_produto">Valor Unitário</label>
              <input type="text" name="valor_produto" class="form-control" placeholder="R$ 00.00" required>
            </div>
            <div class="col-md-4">
              <label for="idfornecedor">ID Fornecedor</label>
              <input type="number" name="idfornecedor" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label for="imagem_produto">Imagem do Produto:</label>
            <input type="file" name="imagem_produto" class="form-control">
          </div>

          <!-- Rodapé com botões alinhados à esquerda -->
          <div class="modal-footer text-left" style="justify-content: flex-start; display: flex; gap: 10px;">
            <button type="submit" class="btn btn-cadastrar">Salvar</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
