<?php
include_once './conexao.php';
include_once './usuarioProprietaria.php';
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!!";
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home Proprietária - Sistema Floricultura</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Italiana&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <style>
        .navbar-inverse { background-color: #d3bdf0; border-color: #d3bdf0; }
        .navbar-inverse .navbar-header > li > a { color: #3c1361 !important; }
        .navbar-inverse .navbar-nav > li > a {
            font-family: 'Italiana';
            color: #3c1361 !important;
            float: right;
            margin-top: 20px;
        }
        .navbar-text {
            color: #3c1361 !important;
            float: right;
            margin-top: 40px;
        }
        .navbar-brand {
            font-family: 'Italiana', serif;
            color: #3c1361 !important;
            font-size: 24px;
        }
        .page-title-box {
            font-family: 'Italiana';
            background-color: #d3bdf0;
            padding: 15px;
            border-radius: 10px;
            margin: 40px auto 20px auto;
            text-align: center;
            max-width: 600px;
        }
        .page-title-box h2 {
            color: #3c1361;
            margin: 0;
        }
    </style>
</head>
<body>

<header>
        <div class="header-container">
            <div class="logo">
            <a href="homeFuncionario.php"><img src="logo_header.png" alt="Logo da floricultura" class="logo-img"></a>
        <div class="logo-texto">
    <h1>Matos e Flores</h1>
    <span>Loja de Plantas Ornamentais</span>
  </div>
</div>
            <nav>
                <ul>
                     <li><a href="homeProprietaria.php">Início</a></li>
                     <li><a href="cadastroFuncionario.php">Cadastro Funcionário</a></li>
                     <li><a href="listaFuncionario.php">Lista Funcionários</a></li>
                     <li><a href="listaFornecedores.php">Lista Fornecedores</a></li>

                </ul>
            </nav>
            <div class="user-actions">
               <div class="user-actions">
                <div class="user-greeting">
                    Olá, <?php echo $_SESSION['user']->nome_proprietaria; ?>!
                </div>
                <a href="logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>

<div class="boas-vindas">
    <div class="logo-texto">
        <h2>Bem-vindo(a), <?php echo $_SESSION['user']->nome_proprietaria; ?>!</h2> 
    </div>
    <img src="funcionario.png" align-itens="center">
</div>

</body>
</html>