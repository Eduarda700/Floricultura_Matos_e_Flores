<?php
include_once("conexao.php");
include_once("usuarioFuncionario.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || $_SESSION['tipo'] !== 'funcionario') {
    header("location: index.php");
    exit;
}

$idusuario_funcionario = $_SESSION['user']->idusuario_funcionario;

$sql = "SELECT * FROM dicas_plantio WHERE idusuario_funcionario = $idusuario_funcionario ORDER BY iddica_plantio DESC";
$res = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lista de Dicas - Sistema Floricultura</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .container-box {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 12px;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .page-title {
            font-family: 'Italiana';
            color: #3c1361;
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background-color: #d3bdf0;
            color: #3c1361;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        a.action-link {
            margin-right: 10px;
        }
    </style>
</head>
<body>

<header>
        <div class="header-container">
            <div class="logo">
            <a href="homeFuncionario.php"><img src="logo_header.png" alt="Logo da floricultura" class="logo-img"></a>
        <div class="logo-texto">
    <h1>Matos e Flores</h1>
    <span>Loja de Plantas Ornamentais</span>
  </div>
</div>
            <nav>
                <ul>
                    <li><a href="homeFuncionario.php">Início</a></li>
                    <li><a href="cadastraProdutos.php">Lista Produtos</a></li>
                    <li><a href="lista_dica.php">Lista Dicas de Plantio</a></li>
                   <li><a href="pedidos_andamento.php">Lista de Pedidos </a></li>
                </ul>
            </nav>
            <div class="user-actions">
               <div class="user-actions">
                <div class="user-greeting">
                    Olá, <?php echo $_SESSION['user']->nome_funcionario; ?>!
                </div>
                <a href="logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>

<div class="container">
    <div class="container-box">
        <h2 class="page-title">Lista de Dicas de Plantio</h2>

        <p>
            <a href="cadastra_dica.php" class="btn btn-custom">Cadastrar Nova Dica</a>
        </p>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Conteúdo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($res) > 0): ?>
                <?php while ($dica = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?= $dica['iddica_plantio'] ?></td>
                        <td><?= htmlspecialchars($dica['titulo_dica']) ?></td>
                        <td><?= nl2br(htmlspecialchars(substr($dica['conteudo_dica'], 0, 100))) ?>...</td>
                        <td>
                            <a class="action-link" href="exibe_dica.php?iddica_plantio=<?= $dica['iddica_plantio'] ?>">Exibir</a>
                            <a class="action-link" href="altera_dica.php?id=<?= $dica['iddica_plantio'] ?>">Editar</a>
                            <a class="action-link" href="processa_exclui_dica.php?id=<?= $dica['iddica_plantio'] ?>" onclick="return confirm('Deseja realmente excluir esta dica?');" style="color:red;">Excluir</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4">Nenhuma dica cadastrada.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
