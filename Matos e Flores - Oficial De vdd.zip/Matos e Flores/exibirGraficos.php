<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Gráficos da Floricultura</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>
        body {
            margin: 0;
            background-color:rgb(229, 219, 242);
            font-family: Arial, sans-serif;
        }

        /* NAVBAR */
        .navbar {
            background-color: #d3bdf0;
            display: flex;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            font-family: 'Italiana', serif;
            color: #3c1361;
            font-size: 24px;
            text-decoration: none;
            margin-right: 30px;
        }

        .navbar-brand img {
            height: 60px;
            margin-right: 10px;
        }

        .navbar-nav {
            display: flex;
            gap: 20px;
        }

        .navbar-nav a {
            font-family: 'Italiana', serif;
            color: #3c1361;
            text-decoration: none;
            font-size: 16px;
            padding: 10px;
        }

        .navbar-text {
            margin-left: auto;
            color: #3c1361;
            font-family: 'Italiana', serif;
        }

        /* GRÁFICOS */
        h1 {
            text-align: center;
            color: #3c1361;
            margin-top: 30px;
        }

        #graficoProdutos, #graficoEstoque, #graficoFuncionarios, #graficoVendas {
            margin: 30px auto;
            width: 600px;
            height: 400px;
            border: 1px solid #d3bdf0;
            box-shadow: 0px 2px 8px rgba(60, 19, 97, 0.1);
        }
    </style>
</head>
<body>

    <!-- MENU -->
    <nav class="navbar">
        <a class="navbar-brand" href="#">
            <img src="img/logo.png" alt="Logo Matos & Flores">
            Sistema Floricultura
        </a>
        <div class="navbar-nav">
            <a href="homeProprietaria.php">Início</a>
            <a href="cadastroFuncionario.php">Cadastro Funcionário</a>
            <a href="listaFuncionario.php">Lista Funcionários</a>
            <a href="listaFornecedores.php">Lista Fornecedores</a>
            <a href="logout.php">Sair</a>
        </div>
    </nav>

    <!-- TÍTULO -->
    <h1>Gráficos da Floricultura</h1>

    <!-- DIVS DE GRÁFICO -->
    <div id="graficoProdutos"></div>
    <div id="graficoEstoque"></div>
    <div id="graficoFuncionarios"></div>
    <div id="graficoVendas"></div>

    <!-- SCRIPT DE GRÁFICOS -->
    <script src="grafico.js"></script>
</body>
</html>