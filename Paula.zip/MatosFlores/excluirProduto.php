<?php
$conn = new mysqli("localhost", "root", "root", "floricultura");
if ($conn->connect_error) {
    die("Erro: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $sql = "DELETE FROM produto WHERE idproduto = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao excluir: " . $conn->error;
    }
} else {
    echo "ID não fornecido.";
}
?>
