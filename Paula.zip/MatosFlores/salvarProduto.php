<?php
$mysqli = new mysqli("localhost", "root", "root", "floricultura");
if ($mysqli->connect_error) die("Erro: " . $mysqli->connect_error);

$nome = $_POST['nome_produto'];
$codigo = $_POST['cod_produto'];
$descricao = $_POST['descricao_produto'];
$quantidade = $_POST['quantidade_produto'];
$valor = $_POST['valor_produto'];
$idfornecedor = $_POST['idfornecedor'];

$stmt = $mysqli->prepare("INSERT INTO produto (nome_produto, cod_produto, descricao_produto, quantidade_produto, valor_produto, idfornecedor) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssisi", $nome, $codigo, $descricao, $quantidade, $valor, $idfornecedor);
$stmt->execute();

    // Verificação de upload da imagem
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        $nomeImagem = $_FILES['imagem']['name'];
        $caminhoTemporario = $_FILES['imagem']['tmp_name'];

        // Caminho onde a imagem será salva
        $destino = 'imagens/' . basename($nomeImagem);

        // Move o arquivo para a pasta destino
        move_uploaded_file($caminhoTemporario, $destino);
    } else {
        $destino = null; // ou um valor padrão
    }

header("Location: index.php");
exit;
