<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Pedidos em Andamento</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f0ff;
      padding: 2rem;
      font-family: 'Segoe UI', sans-serif;
    }
    .titulo {
      color: #7e5dba;
      font-size: 1.8rem;
      margin-bottom: 2rem;
    }
    .card-pedido {
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0 3px 6px rgba(0,0,0,0.1);
      padding: 1.5rem;
      position: relative;
    }
    .preco {
      position: absolute;
      top: 0;
      right: 0;
      background-color: #f3eaff;
      color: #2c135f;
      font-weight: bold;
      padding: 0.8rem 1.5rem;
      border-radius: 0 10px 0 20px;
    }
    .imagem-produto {
      width: 100px;
      height: auto;
      margin-top: 1rem;
    }
    .info-extra {
      font-size: 0.9rem;
      color: #555;
    }
    .info-extra b {
      color: #2c135f;
    }
  </style>
</head>
<body>

  <h2 class="titulo">Pedidos em andamento</h2>

  <div class="row row-cols-1 row-cols-md-2 g-4">
    <!-- Card de Pedido -->
    <div class="col">
      <div class="card-pedido h-100">
        <div class="preco">R$ 210,99</div>
        <h5 class="mb-2">Vaso de Flores Tropicais - 500ml</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <img src="imagens/flores1.png" class="imagem-produto" alt="Imagem do Produto">
        <p class="info-extra mt-3">Método de Pagamento: <b>Débito</b><br>Endereço: Rua dos Bobos, 0 - Centro, Botucatu</p>
      </div>
    </div>

    <!-- Clone para mais pedidos -->
    <div class="col">
      <div class="card-pedido h-100">
        <div class="preco">R$ 210,99</div>
        <h5 class="mb-2">Vaso de Flores Tropicais - 500ml</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        <img src="imagens/flores2.png" class="imagem-produto" alt="Imagem do Produto">
        <p class="info-extra mt-3">Método de Pagamento: <b>Débito</b><br>Endereço: Rua dos Bobos, 0 - Centro, Botucatu</p>
      </div>
    </div>

    <!-- Adicione mais colunas aqui conforme necessário -->

  </div>

</body>
</html>
