<?php
// conexão com o banco
$conn = new mysqli("localhost", "root", "root", "floricultura");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// consulta para buscar os dados
$sql = "SELECT 
    p.nome_produto, 
    p.descricao_produto, 
    p.valor_produto, 
    v.idvenda,
    mp.cartao, mp.pix, mp.dinheiro,
    u.nome_cliente, u.rua_cliente, u.numero_cliente, u.bairro_cliente, u.cidade_cliente,
    pr.imagem
FROM pedidos_realizados pr
INNER JOIN produto p ON pr.idproduto = p.idproduto
INNER JOIN venda v ON pr.idvenda = v.idvenda
INNER JOIN modo_de_pagamento mp ON v.idmodo_de_pagamento = mp.idmodo_de_pagamento
INNER JOIN usuario_cliente u ON v.idusuario_cliente = u.idusuario_cliente";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Pedidos em Andamento</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="estilo-pedidos.css">
</head>
<body style="background-color: #f4ecff; padding: 2rem;">

  <h2 class="mb-4" style="color:#57396d;">Pedidos em Andamento</h2>

  <div class="container">
    <div class="row g-4">
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="col-md-6">
          <div class="card shadow rounded p-3" style="border-left: 10px solid #c6b1e6;">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <h5 class="fw-bold"><?= htmlspecialchars($row['nome_produto']) ?> – 500ml</h5>
                <p style="max-width: 80%"><?= nl2br(htmlspecialchars($row['descricao_produto'])) ?></p>
                <p><strong>Método de Pagamento:</strong> <span style="color: #57396d;"> 
                  <?= $row['pix'] ? 'Pix' : ($row['cartao'] ? 'Cartão' : 'Dinheiro') ?>
                </span></p>
                <p><strong>Endereço:</strong> Rua <?= $row['rua_cliente'] ?>, <?= $row['numero_cliente'] ?> – <?= $row['bairro_cliente'] ?>, <?= $row['cidade_cliente'] ?></p>
              </div>
              <div class="text-center">
                <p class="fs-5 fw-bold" style="color:#57396d;">R$ <?= $row['valor_produto'] ?></p>
                <img src="uploads/<?= htmlspecialchars($row['imagem']) ?>" class="img-fluid rounded" style="max-height: 100px;" alt="Produto">
              </div>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>

</body>
</html>
